package com.eazybytes.accounts.services;

import com.eazybytes.accounts.Exceptions.CustomerAlreadyExistsException;
import com.eazybytes.accounts.Exceptions.ResourceNotFoundException;
import com.eazybytes.accounts.dto.CustomerDto;

public interface IAccountsServices {

    /*
    * @param customerDto - CustomerDto Object
    *
    * */
    void createAccount(CustomerDto customerDto) throws CustomerAlreadyExistsException;

    /*
    *
    * @param mobileNumber - Input mobile number
    * @return Accounts Details based on a given mobileNumber
    * */

    CustomerDto fetchAccount(String mobileNumber) throws ResourceNotFoundException;

    /*
    * @param customerDto - CustomerDto Object
    * @return boolean indicating if the update of Account details is successful or not
    * */

    boolean updateAccount(CustomerDto customerDto) throws ResourceNotFoundException;


    /*
    * @param mobile number - Input mobile Number
    * @return boolean indicating if the delete of Account is successful or not
    * */

    boolean deleteAccount(String mobileNumber) throws ResourceNotFoundException;
}
